from tkinter import *
import sqlite3


root = Tk()
root.geometry('500x600')
root.title("EMPLOYEE APPOINTEMENT")


Employeename = StringVar()
Employeeid = StringVar()
Mobileno = StringVar()
Email = StringVar()
Aadhar = StringVar()
Age = StringVar()
Salary = StringVar()
Gender = IntVar()
Employeetype = StringVar()

def employdatabase():
    employeename = Employeename.get()
    employeeid = Employeeid.get()
    mobile = Mobileno.get()
    email = Email.get()
    aadhar = Aadhar.get()
    age = Age.get()
    salary = Salary.get()
    gender = Gender.get()
    employeetype = Employeetype.get()
    conn = sqlite3.connect('EMPLOYEE APPOINTMENT RECORDS.db')
    with conn:
        cursor = conn.cursor()
    cursor.execute(
        'CREATE TABLE IF NOT EXISTS Employee (Employeename TEXT,Employeeid TEXT,Mobileno TEXT,Email TEXT,Aadhar TEXT,Age TEXT,Salary TEXT,Gender TEXT,Employeetype TEXT)')
    cursor.execute('INSERT INTO Employee (Employeename,Employeeid,Mobileno,Email,Aadhar,Age,Salary,Gender,Employeetype) VALUES(?,?,?,?,?,?,?,?,?)',
                   (employeename,employeeid,mobile,email,aadhar,age,salary,gender,employeetype,))
    conn.commit()

def reg():
	label_0 = Label(root, text="EMPLOYEE APPOINTMENT RECORDS", fg='red', width=0, 		font=("bold", 15))
	label_0.place(x=90, y=53)
	

	label_1 = Label(root, text="ENTER EMPLOYEE NAME", width=20, font=("bold", 9))
	label_1.place(x=80, y=130)
	
	entry_1 = Entry(root, textvar=Employeename)
	entry_1.place(x=240, y=130)
	
	label_2 = Label(root, text="ENTER EMPLOYEE ID", width=20, font=("bold", 9))
	label_2.place(x=80, y=155)
	
	entry_2 = Entry(root, textvar=Employeeid)
	entry_2.place(x=240, y=155)
	
	label_3 = Label(root, text="ENTER MOBILE NO.", width=20, font=("bold", 9))
	label_3.place(x=80, y=180)
	
	entry_3 = Entry(root, textvar=Mobileno)
	entry_3.place(x=240, y=180)
		
	label_4 = Label(root, text="ENTER EMAIL", width=20, font=("bold", 9))
	label_4.place(x=80, y=205)

	entry_4= Entry(root, textvar=Email)
	entry_4.place(x=240, y=205)

	label_5 = Label(root, text="ENTER AADHAR NO.", width=20, font=("bold", 9))
	label_5.place(x=80, y=230)
	
	entry_5 = Entry(root, textvar=Aadhar)
	entry_5.place(x=240, y=230)

	label_6 = Label(root, text="AGE", width=20, font=("bold", 9))
	label_6.place(x=80, y=255)
		
	entry_6 = Entry(root, textvar=Age)
	entry_6.place(x=240, y=255)
	
	label_7 = Label(root, text="SALARY", width=20, font=("bold", 9))
	label_7.place(x=80, y=280)
	
	entry_7 = Entry(root, textvar=Salary)
	entry_7.place(x=240, y=280)	


	label_8 = Label(root, text="SELECT GENDER", width=20, font=("bold", 9))
	label_8.place(x=80, y=305)

	r1 = Radiobutton(root, text="MALE", padx=5, variable=Gender, value=1)
	r1.place(x=235, y=305)
	r2 = Radiobutton(root, text="FEMALE", padx=20, variable=Gender, value=2)
	r2.place(x=300, y=305)

	label_9 = Label(root, text="SELECT EMPLOYEE TYPE", width=20, font=("bold", 9))
	label_9.place(x=70, y=330)

	list12 = ['Doctor', 'Nurse', 'Floor sweeper'];

	droplist = OptionMenu(root, Employeetype, *list12)
	droplist.config(bg='yellow', fg='black', width=15)
	Employeetype.set('Select Employee Type')
	droplist.place(x=240, y=330)

	
	Button(root, text='Submit', width=20, bg='green', fg='black', command=employdatabase).place(x=180, y=440)
	#Button(root, text='Submit', width=20, bg='green', fg='black', command=employdatabase)
	
	root.mainloop()


