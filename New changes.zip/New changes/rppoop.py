
# -*- coding: utf-8 -*-
from tkinter import *
import sqlite3

roote = Tk()
roote.geometry('500x600')
roote.title('EMPLOYEE APPOINTEMENT')

Employeename = StringVar()
Employeeid = StringVar()
Mobileno = StringVar()
Email = StringVar()
Aadhar = StringVar()
Age = StringVar()
Salary = StringVar()
Gender = IntVar()
Employeetype = StringVar()


def employdatabase():
    employeename = Employeename.get()
    employeeid = Employeeid.get()
    mobile = Mobileno.get()
    email = Email.get()
    aadhar = Aadhar.get()
    age = Age.get()
    salary = Salary.get()
    gender = Gender.get()
    employeetype = Employeetype.get()
    conn = sqlite3.connect('EMPLOYEE APPOINTMENT RECORDS.db')
    with conn:
        cursor = conn.cursor()
    cursor.execute(
        'CREATE TABLE IF NOT EXISTS Employee (Employeename TEXT,Mobileno TEXT,Email TEXT,Aadhar TEXT,Age TEXT,Employeetype TEXT,Salary TEXT,Gender TEXT,Employeeid TEXT)')
    cursor.execute('INSERT INTO Patient (Employeename,Employeeid,Mobileno,Email,Aadhar,Age,Salary,Gender,Employeetype) VALUES(?,?,?,?,?,?,?,?,?)',
                   (employeename,employeeid,mobile,email,aadhar,age,employeetype,salary,gender,))
    conn.commit()



label_0 = Label(roote, text='EMPLOYEE APPOINTMENT RECORDS', fg='red' , width=0, font=('bold', 15))
label_0.place(x=90, y=53)

label_1 = Label(roote, text='ENTER EMPLOYEE NAME', width=20,font=('bold', 9))
label_1.place(x=80, y=130)

entry_1 = Entry(roote, textvar=Employeename)
entry_1.place(x=240, y=130)

label_2 = Label(roote, text='ENTER EMPLOYEE ID', width=20,font=('bold', 9))
label_2.place(x=80, y=155)

entry_2 = Entry(roote, textvar=Employeeid)
entry_2.place(x=240, y=155)

label_3 = Label(roote, text='ENTER MOBILE NO.', width=20,font=('bold', 9))
label_3.place(x=80, y=180)

entry_3 = Entry(roote, textvar=Mobileno)
entry_3.place(x=240, y=180)

label_4 = Label(roote, text='ENTER EMAIL', width=20, font=('bold',9))
label_4.place(x=80, y=205)

entry_4 = Entry(roote, textvar=Email)
entry_4.place(x=240, y=205)

label_5 = Label(roote, text='ENTER AADHAR NO.', width=20,font=('bold', 9))
label_5.place(x=80, y=230)

entry_5 = Entry(roote, textvar=Aadhar)
entry_5.place(x=240, y=230)

label_6 = Label(roote, text='AGE', width=20, font=('bold', 9))
label_6.place(x=80, y=255)

entry_6 = Entry(roote, textvar=Age)
entry_6.place(x=240, y=255)

label_7 = Label(roote, text='SALARY', width=20, font=('bold', 9))
label_7.place(x=80, y=280)

entry_7 = Entry(roote, textvar=Salary)
entry_7.place(x=240, y=280)

label_8 = Label(roote, text='SELECT GENDER', width=20, font=('bold', 9))
label_8.place(x=80, y=305)

r1 = Radiobutton(roote, text='MALE', padx=5, variable=Gender, value=1)
r1.place(x=235, y=305)
r2 = Radiobutton(roote, text='FEMALE', padx=20, variable=Gender,value=2)
r2.place(x=300, y=305)

    # label_7 = Label(root, text=" COVID SYMPOTMS?", width=20, font=("bold", 9))
    # label_7.place(x=80, y=280)

label_9 = Label(roote, text='SELECT EMPLOYEE TYPE', width=20,font=('bold', 9))
label_9.place(x=70, y=330)

list12 = ['Doctor', 'Nurse', 'Floor sweeper']

droplist = OptionMenu(roote, Employeetype, *list12)
droplist.config(bg='yellow', fg='black', width=15)
Employeetype.set('Select ')
droplist.place(x=240, y=330)

Button(roote,text='Submit',width=20,bg='green',fg='black',command=employdatabase,).place(x=180, y=440)
    
roote.mainloop()
