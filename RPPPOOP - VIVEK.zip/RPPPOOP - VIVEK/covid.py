import webbrowser
new = 1
url = "https://www.covid19india.org/"
def openweb():
    webbrowser.open(url,new=new)



