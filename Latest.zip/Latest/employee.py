from tkinter import *
import sqlite3


root = Tk()
root.geometry('500x600')
root.title("EMPLOYEE APPOINTEMENT")



	
	root.mainloop()


